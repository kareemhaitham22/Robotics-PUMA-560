function qm = I_K_team20k(x,y,z)

q1 = 90;
q2 = 90;
q3 = 90;
q4 = 0;
q5 = 0;
q6 = 0;
l1 = 30 ;
l2 = 17;
l3 = 17;
qm = [ q1 ; q2 ; q3 ; q4 ; q5 ; q6 ];

n = 5000;
qmold = qm;

while n > 1
    n = n-1;
    J11 = 17*sind(q1)*sind(q2)*sind(q3) - 17*cosd(q2)*sind(q1) - 17*cosd(q2)*cosd(q3)*sind(q1);
    J12 = - 17*cosd(q1)*sind(q2) - 17*cosd(q1)*cosd(q2)*sind(q3) - 17*cosd(q1)*cosd(q3)*sind(q2);
    J13 = - 17*cosd(q1)*cosd(q2)*sind(q3) - 17*cosd(q1)*cosd(q3)*sind(q2);
    J14 = 0;
    J15 = 0;
    J16 = 0;
    J21 = 17*cosd(q1)*cosd(q2) + 17*cosd(q1)*cosd(q2)*cosd(q3) - 17*cosd(q1)*sind(q2)*sind(q3);
    J22 = - 17*sind(q1)*sind(q2) - 17*cosd(q2)*sind(q1)*sind(q3) - 17*cosd(q3)*sind(q1)*sind(q2);
    J23 = - 17*cosd(q2)*sind(q1)*sind(q3) - 17*cosd(q3)*sind(q1)*sind(q2);
    J24 = 0;
    J25 = 0;
    J26 = 0;
    J31 = 0;
    J32 = 17*cosd(q2) + 17*cosd(q2)*cosd(q3) - 17*sind(q2)*sind(q3);
    J33 = 17*cosd(q2)*cosd(q3) - 17*sind(q2)*sind(q3);
    J34 = 0;
    J35 = 0;
    J36 = 0;
    J = [J11 J12 J13 J14 J15 J16 ; J21 J22 J23 J24 J25 J26 ; J31 J32 J33 J34 J35 J36 ];
    Ji = pinv(J);
    px = l2*cosd(q1)*cosd(q2) + l3*cosd(q1)*cosd(q2)*cosd(q3) - l3*cosd(q1)*sind(q2)*sind(q3) ;
    py = l2*cosd(q2)*sind(q1) + l3*cosd(q2)*cosd(q3)*sind(q1) - l3*sind(q1)*sind(q2)*sind(q3) ;
    pz = l1 + l2*sind(q2) + l3*cosd(q2)*sind(q3) + l3*cosd(q3)*sind(q2) ;
    f1 = px -x;
    f2 = py -y;
    f3 = pz -z;
    fm = [ f1 ; f2 ; f3 ];
    qm = [ q1 ; q2 ; q3 ; q4 ; q5 ; q6 ];
    
    qm = qm - Ji*fm; 
     if ( (qmold(1,1)==qm(1,1) ) && (qmold(2,1)==qm(2,1) ) && (qmold(3,1)==qm(3,1) ) && (qmold(4,1)==qm(4,1) ) && (qmold(5,1)==qm(5,1) ) && (qmold(6,1)==qm(6,1) ) && ne(fm(1,1),0) &&  ne(fm(2,1),0) && ne(fm(3,1),0) )  
         
         qm = qm *2;
     end
     if ( (qmold(1,1)==qm(1,1) ) && (qmold(2,1)==qm(2,1) ) && (qmold(3,1)==qm(3,1) ) && (qmold(4,1)==qm(4,1) ) && (qmold(5,1)==qm(5,1) ) && (qmold(6,1)==qm(6,1) ) && eq(fm(1,1),0) &&  eq(fm(2,1),0) && eq(fm(3,1),0) )  
        break;
     end
    qmold = qm;
    q1=qm(1,1);
    q2=qm(2,1);
    q3=qm(3,1);
    q4=qm(4,1);
    q5=qm(5,1);
    q6=qm(6,1);
    if ( (q1<1 && q1>0) || (q1>-1 && q1<0) )
        q1 = 0;
    end
    if ( (q2<1 && q2>0) || (q2>-1 && q2<0) )
        q2 = 0;
    end
    if ( (q3<1 && q3>0) || (q3>-1 && q3<0) )
        q3 = 0;
    end
    if ( (q4<1 && q4>0) || (q4>-1 && q4<0) )
        q4 = 0;
    end
    if ( (q5<1 && q5>0) || (q5>-1 && q5<0) )
        q5 = 0;
    end
    if ( (q6<1 && q6>0) || (q6>-1 && q6<0) )
        q6 = 0;
    end
end









