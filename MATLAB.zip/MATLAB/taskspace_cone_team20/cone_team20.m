i = 1;
cone_5laps_team20 = zeros(100,10);
for t = 0:0.01:1
    x = 0 - 34*t;
    y = (-17+17*t)*cos(10*pi*t);
    z = (-17+17*t)*sin(10*pi*t);
    cone_5laps_team20(i,1) = x;
    cone_5laps_team20(i,2) = y;
    cone_5laps_team20(i,3) = z;
    qm = I_K_team20k(x,y,z);
    cone_5laps_team20(i,4) = qm(1,1);
    cone_5laps_team20(i,5) = qm(2,1);
    cone_5laps_team20(i,6) = qm(3,1);
    cone_5laps_team20(i,7) = qm(4,1);
    cone_5laps_team20(i,8) = qm(5,1);
    cone_5laps_team20(i,9) = qm(6,1);
    cone_5laps_team20(i,10) = t;
    i = i+1;   
end
plot3(cone_5laps_team20(:,1),cone_5laps_team20(:,2),cone_5laps_team20(:,3))
grid





    