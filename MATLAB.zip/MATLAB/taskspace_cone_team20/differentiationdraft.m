syms t ...

y = (-17+17*t)*cosd(10*180*t);
yd = diff(y,t)
ydd = diff(yd,t)

z = (-17+17*t)*sind(10*180*t);
zd = diff(z,t)
zdd = diff(zd,t)