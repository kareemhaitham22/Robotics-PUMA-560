syms t ...

y = (-64+17*t)*cosd(10*180*t)+47;
yd = diff(y,t);
ydd = diff(yd,t);

z =  (-64+17*t)*cosd(10*180*t)+47;
zd = diff(z,t);
zdd = diff(zd,t);

