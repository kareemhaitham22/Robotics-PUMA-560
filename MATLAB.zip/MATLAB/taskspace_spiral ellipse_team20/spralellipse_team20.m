% a spiral ellipse from (0,-17,47) to (0,0,64)
i = 1;
spiral_ellipse_team20 = zeros(100,10);

for t = 0:0.01:1
    x = 0;
    y = (-64+17*t)*cos(10*pi*t)+47;
    z = (-64+17*t)*sin(10*pi*t)+47;
    spiral_ellipse_team20(i,1) = x;
    spiral_ellipse_team20(i,2) = y;
    spiral_ellipse_team20(i,3) = z;
    qm = I_K_team20k(x,y,z);
    spiral_ellipse_team20(i,4) = qm(1,1);
    spiral_ellipse_team20(i,5) = qm(2,1);
    spiral_ellipse_team20(i,6) = qm(3,1);
    spiral_ellipse_team20(i,7) = qm(4,1);
    spiral_ellipse_team20(i,8) = qm(5,1);
    spiral_ellipse_team20(i,9) = qm(6,1);
    spiral_ellipse_team20(i,10) = t;
    i = i+1;   
end
plot3(spiral_ellipse_team20(:,1),spiral_ellipse_team20(:,2),spiral_ellipse_team20(:,3));
grid





    