syms   q1 q2 q3 q4 q5 q6 q1d q2d q3d q4d q5d q6d ;

l1 = 30 ;
l2 = 17;
l3 = 17;
% px = l2*cos(q1)*cos(q2) + l3*cos(q1)*cos(q2)*cos(q3) - l3*cos(q1)*sin(q2)*sin(q3) ;
% py = l2*cos(q2)*sin(q1) + l3*cos(q2)*cos(q3)*sin(q1) - l3*sin(q1)*sin(q2)*sin(q3) ;
% pz = l1 + l2*sin(q2) + l3*cos(q2)*sin(q3) + l3*cos(q3)*sin(q2) ;
% xd11 = diff(px,q1)
% xd12 = diff(px,q2);
% xd13 = diff(px,q3);
% xd14 = diff(px,q4);
% xd15 = diff(px,q5);
% xd16 = diff(px,q6);
% yd21 = diff(py,q1);
% yd22 = diff(py,q2);
% yd23 = diff(py,q3);
% yd24 = diff(py,q4);
% yd25 = diff(py,q5);
% yd26 = diff(py,q6);
% zd31 = diff(pz,q1);
% zd32 = diff(pz,q2);
% zd33 = diff(pz,q3);
% zd34 = diff(pz,q4);
% zd35 = diff(pz,q5);
% zd36 = diff(pz,q6);
% J = [xd11 xd12 xd13 xd14 xd15 xd16 ; yd21 yd22 yd23 yd24 yd25 yd26 ; zd31 zd32 zd33 zd34 zd35 zd36];
% Jinv = pinv(J);
% Jinv(1,1);
% Jinv(1,2);
% Jinv(1,3);
% Jinv(2,1);
% Jinv(2,2);
% Jinv(2,3);
% Jinv(3,1);
% Jinv(3,2);
% Jinv(3,3);
% Jinv(4,1);
% Jinv(4,2);
% Jinv(5,1);
% Jinv(5,2);
% Jinv(5,3);
% Jinv(6,1);
% Jinv(6,2);
% Jinv(6,3);

    J11 = 17*sind(q1)*sind(q2)*sind(q3) - 17*cosd(q2)*sind(q1) - 17*cosd(q2)*cosd(q3)*sind(q1);
    J12 = - 17*cosd(q1)*sind(q2) - 17*cosd(q1)*cosd(q2)*sind(q3) - 17*cosd(q1)*cosd(q3)*sind(q2);
    J13 = - 17*cosd(q1)*cosd(q2)*sind(q3) - 17*cosd(q1)*cosd(q3)*sind(q2);
    J14 = 0;
    J15 = 0;
    J16 = 0;
    J21 = 17*cosd(q1)*cosd(q2) + 17*cosd(q1)*cosd(q2)*cosd(q3) - 17*cosd(q1)*sind(q2)*sind(q3);
    J22 = - 17*sind(q1)*sind(q2) - 17*cosd(q2)*sind(q1)*sind(q3) - 17*cosd(q3)*sind(q1)*sind(q2);
    J23 = - 17*cosd(q2)*sind(q1)*sind(q3) - 17*cosd(q3)*sind(q1)*sind(q2);
    J24 = 0;
    J25 = 0;
    J26 = 0;
    J31 = 0;
    J32 = 17*cosd(q2) + 17*cosd(q2)*cosd(q3) - 17*sind(q2)*sind(q3);
    J33 = 17*cosd(q2)*cosd(q3) - 17*sind(q2)*sind(q3);
    J34 = 0;
    J35 = 0;
    J36 = 0;
    jw1 = [ 0 ; 0 ; 0 ];
    jw2 = [ sind(q1) ; -cosd(q1) ; 0 ];
    jw3 = [ sind(q1) ; -cosd(q1) ; 0 ];
    jw4 = [ sind(q1) ; -cosd(q1) ; 0 ];
    jw5 = [ cos(q4)*(cos(q1)*cos(q2)*sin(q3)+cos(q1)*cos(q3)*sin(q2))+sin(q4)*(cos(q1)*cos(q2)*cos(q3)-cos(q1)*sin(q2)*sin(q3)) ; cos(q4)*(cos(q2)*sin(q1)*sin(q3)+cos(q3)*sin(q1)*sin(q2))-sin(q4)*(sin(q1)*sin(q2)*sin(q3)-cos(q2)*cos(q3)*sin(q1)) ; sin(q4)*(cos(q2)*sin(q3)+cos(q3)*sin(q2))-cos(q4)*(cos(q2)*cos(q3)-sin(q2)*sin(q3)) ];
    jw6 = [ cos(q5)*sin(q1)-sin(q5)*(cos(q4)*(cos(q1)*cos(q2)*cos(q3)-cos(q1)*sin(q2)*sin(q3))-sin(q4)*(cos(q1)*cos(q2)*sin(q3)+cos(q1)*cos(q3)*sin(q2))) ; sin(q5)*(cos(q4)*(sin(q1)*sin(q2)*sin(q3)-cos(q2)*cos(q3)*sin(q1))+sin(q4)*(cos(q2)*sin(q1)*sin(q3)+cos(q3)*sin(q1)*sin(q2)))-cos(q1)*cos(q5) ; -sin(q5)*(cos(q4)*(cos(q2)*sin(q3)+cos(q3)*sin(q2))+sin(q4)*(cos(q2)*cos(q3)-sin(q2)*sin(q3))) ];
    
    J = [J11 J12 J13 J14 J15 J16 ; J21 J22 J23 J24 J25 J26 ; J31 J32 J33 J34 J35 J36 ; jw1(1,1) jw2(1,1) jw3(1,1) jw4(1,1) jw5(1,1) jw6(1,1) ; jw1(2,1) jw2(2,1) jw3(2,1) jw4(2,1) jw5(2,1) jw6(2,1) ; jw1(3,1) jw2(3,1) jw3(3,1) jw4(3,1) jw5(3,1) jw6(3,1) ]; 
 
    J41 = jw1(1,1);
    J51 = jw1(2,1);
    J61 = jw1(3,1);
    J42 = jw2(1,1);
    J52 = jw2(2,1);
    J62 = jw2(3,1);
    J43 = jw3(1,1);
    J53 = jw3(2,1);
    J63 = jw3(3,1);
    J44 = jw4(1,1);
    J54 = jw4(2,1);
    J64 = jw4(3,1);
    J45 = jw5(1,1);
    J55 = jw5(2,1);
    J65 = jw5(3,1);
    J46 = jw6(1,1);
    J56 = jw6(2,1);
    J66 = jw6(3,1);
    

    jd11 = diff(J11 ,q1)*q1d + diff(J11 ,q2)*q2d + diff(J11 ,q3)*q3d + diff(J11 ,q4)*q4d + diff(J11 ,q5)*q5d + diff(J11 ,q6)*q6d;
    jd12 = diff(J12 ,q1)*q1d + diff(J12 ,q2)*q2d + diff(J12 ,q3)*q3d + diff(J12 ,q4)*q4d + diff(J12 ,q5)*q5d + diff(J12 ,q6)*q6d;
    jd13 = diff(J13 ,q1)*q1d + diff(J13 ,q2)*q2d + diff(J13 ,q3)*q3d + diff(J13 ,q4)*q4d + diff(J13 ,q5)*q5d + diff(J13 ,q6)*q6d;
    jd14 = diff(J14 ,q1)*q1d + diff(J14 ,q2)*q2d + diff(J14 ,q3)*q3d + diff(J14 ,q4)*q4d + diff(J14 ,q5)*q5d + diff(J14 ,q6)*q6d;
    jd15 = diff(J15 ,q1)*q1d + diff(J15 ,q2)*q2d + diff(J15 ,q3)*q3d + diff(J15 ,q4)*q4d + diff(J15 ,q5)*q5d + diff(J15 ,q6)*q6d;
    jd16 = diff(J16 ,q1)*q1d + diff(J16 ,q2)*q2d + diff(J16 ,q3)*q3d + diff(J16 ,q4)*q4d + diff(J16 ,q5)*q5d + diff(J16 ,q6)*q6d;
    
    jd21 = diff(J21 ,q1)*q1d + diff(J21 ,q2)*q2d + diff(J21 ,q3)*q3d + diff(J21 ,q4)*q4d + diff(J21 ,q5)*q5d + diff(J21 ,q6)*q6d;
    jd22 = diff(J22 ,q1)*q1d + diff(J22 ,q2)*q2d + diff(J22 ,q3)*q3d + diff(J22 ,q4)*q4d + diff(J22 ,q5)*q5d + diff(J22 ,q6)*q6d;
    jd23 = diff(J23 ,q1)*q1d + diff(J23 ,q2)*q2d + diff(J23 ,q3)*q3d + diff(J23 ,q4)*q4d + diff(J23 ,q5)*q5d + diff(J23 ,q6)*q6d;
    jd24 = diff(J24 ,q1)*q1d + diff(J24 ,q2)*q2d + diff(J24 ,q3)*q3d + diff(J24 ,q4)*q4d + diff(J24 ,q5)*q5d + diff(J24 ,q6)*q6d;
    jd25 = diff(J25 ,q1)*q1d + diff(J25 ,q2)*q2d + diff(J25 ,q3)*q3d + diff(J25 ,q4)*q4d + diff(J25 ,q5)*q5d + diff(J25 ,q6)*q6d;
    jd26 = diff(J26 ,q1)*q1d + diff(J26 ,q2)*q2d + diff(J26 ,q3)*q3d + diff(J26 ,q4)*q4d + diff(J26 ,q5)*q5d + diff(J26 ,q6)*q6d;

    jd31 = diff(J31 ,q1)*q1d + diff(J31 ,q2)*q2d + diff(J31 ,q3)*q3d + diff(J31 ,q4)*q4d + diff(J31 ,q5)*q5d + diff(J31 ,q6)*q6d;
    jd32 = diff(J32 ,q1)*q1d + diff(J32 ,q2)*q2d + diff(J32 ,q3)*q3d + diff(J32 ,q4)*q4d + diff(J32 ,q5)*q5d + diff(J32 ,q6)*q6d;
    jd33 = diff(J33 ,q1)*q1d + diff(J33 ,q2)*q2d + diff(J33 ,q3)*q3d + diff(J33 ,q4)*q4d + diff(J33 ,q5)*q5d + diff(J33 ,q6)*q6d;
    jd34 = diff(J34 ,q1)*q1d + diff(J34 ,q2)*q2d + diff(J34 ,q3)*q3d + diff(J34 ,q4)*q4d + diff(J34 ,q5)*q5d + diff(J34 ,q6)*q6d;
    jd35 = diff(J35 ,q1)*q1d + diff(J35 ,q2)*q2d + diff(J35 ,q3)*q3d + diff(J35 ,q4)*q4d + diff(J35 ,q5)*q5d + diff(J35 ,q6)*q6d;
    jd36 = diff(J36 ,q1)*q1d + diff(J36 ,q2)*q2d + diff(J36 ,q3)*q3d + diff(J36 ,q4)*q4d + diff(J36 ,q5)*q5d + diff(J36 ,q6)*q6d;

    jd41 = diff(J41 ,q1)*q1d + diff(J41 ,q2)*q2d + diff(J41 ,q3)*q3d + diff(J41 ,q4)*q4d + diff(J41 ,q5)*q5d + diff(J41 ,q6)*q6d;
    jd42 = diff(J42 ,q1)*q1d + diff(J42 ,q2)*q2d + diff(J42 ,q3)*q3d + diff(J42 ,q4)*q4d + diff(J42 ,q5)*q5d + diff(J42 ,q6)*q6d;
    jd43 = diff(J43 ,q1)*q1d + diff(J43 ,q2)*q2d + diff(J43 ,q3)*q3d + diff(J43 ,q4)*q4d + diff(J43 ,q5)*q5d + diff(J43 ,q6)*q6d;
    jd44 = diff(J44 ,q1)*q1d + diff(J44 ,q2)*q2d + diff(J44 ,q3)*q3d + diff(J44 ,q4)*q4d + diff(J44 ,q5)*q5d + diff(J44 ,q6)*q6d;
    jd45 = diff(J45 ,q1)*q1d + diff(J45 ,q2)*q2d + diff(J45 ,q3)*q3d + diff(J45 ,q4)*q4d + diff(J45 ,q5)*q5d + diff(J45 ,q6)*q6d;
    jd46 = diff(J46 ,q1)*q1d + diff(J46 ,q2)*q2d + diff(J46 ,q3)*q3d + diff(J46 ,q4)*q4d + diff(J46 ,q5)*q5d + diff(J46 ,q6)*q6d;

    jd51 = diff(J51 ,q1)*q1d + diff(J51 ,q2)*q2d + diff(J51 ,q3)*q3d + diff(J51 ,q4)*q4d + diff(J51 ,q5)*q5d + diff(J51 ,q6)*q6d;
    jd52 = diff(J52 ,q1)*q1d + diff(J52 ,q2)*q2d + diff(J52 ,q3)*q3d + diff(J52 ,q4)*q4d + diff(J52 ,q5)*q5d + diff(J52 ,q6)*q6d;
    jd53 = diff(J53 ,q1)*q1d + diff(J53 ,q2)*q2d + diff(J53 ,q3)*q3d + diff(J53 ,q4)*q4d + diff(J53 ,q5)*q5d + diff(J53 ,q6)*q6d;
    jd54 = diff(J54 ,q1)*q1d + diff(J54 ,q2)*q2d + diff(J54 ,q3)*q3d + diff(J54 ,q4)*q4d + diff(J54 ,q5)*q5d + diff(J54 ,q6)*q6d;
    jd55 = diff(J55 ,q1)*q1d + diff(J55 ,q2)*q2d + diff(J55 ,q3)*q3d + diff(J55 ,q4)*q4d + diff(J55 ,q5)*q5d + diff(J55 ,q6)*q6d;
    jd56 = diff(J56 ,q1)*q1d + diff(J56 ,q2)*q2d + diff(J56 ,q3)*q3d + diff(J56 ,q4)*q4d + diff(J56 ,q5)*q5d + diff(J56 ,q6)*q6d;

    jd61 = diff(J61 ,q1)*q1d + diff(J61 ,q2)*q2d + diff(J61 ,q3)*q3d + diff(J61 ,q4)*q4d + diff(J61 ,q5)*q5d + diff(J61 ,q6)*q6d;
    jd62 = diff(J62 ,q1)*q1d + diff(J62 ,q2)*q2d + diff(J62 ,q3)*q3d + diff(J62 ,q4)*q4d + diff(J62 ,q5)*q5d + diff(J62 ,q6)*q6d;
    jd63 = diff(J63 ,q1)*q1d + diff(J63 ,q2)*q2d + diff(J63 ,q3)*q3d + diff(J63 ,q4)*q4d + diff(J63 ,q5)*q5d + diff(J63 ,q6)*q6d;
    jd64 = diff(J64 ,q1)*q1d + diff(J64 ,q2)*q2d + diff(J64 ,q3)*q3d + diff(J64 ,q4)*q4d + diff(J64 ,q5)*q5d + diff(J64 ,q6)*q6d;
    jd65 = diff(J65 ,q1)*q1d + diff(J65 ,q2)*q2d + diff(J65 ,q3)*q3d + diff(J65 ,q4)*q4d + diff(J65 ,q5)*q5d + diff(J65 ,q6)*q6d;
    jd66 = diff(J66 ,q1)*q1d + diff(J66 ,q2)*q2d + diff(J66 ,q3)*q3d + diff(J66 ,q4)*q4d + diff(J66 ,q5)*q5d + diff(J66 ,q6)*q6d

jd = [ jd11 jd12 jd13 jd14 jd15 jd16 ; jd21 jd22 jd23 jd24 jd25 jd26 ; jd31 jd32 jd33 jd34 jd35 jd36 ; jd41 jd42 jd43 jd44 jd45 jd46 ; jd51 jd52 jd53 jd54 jd55 jd56 ; jd61 jd62 jd63 jd64 jd65 jd66 ];



    



 